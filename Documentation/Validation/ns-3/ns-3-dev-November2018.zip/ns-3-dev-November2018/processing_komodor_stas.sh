#!/bin/bash

MAX_NO_OF_DROPS=20; # maximum number of drops

snrFlag=(0 1); #if true then snr is disabled
snrCnt=2;

PRENAME="Komodor_Eval"

for ((snrInt=1; snrInt<snrCnt; snrInt++))
do 
	OUT_NAME2="Temp_Processing_FileS.tr"
	OUT_AVE="Final_STAs_${PRENAME}_SNR_${snrFlag[$snrInt]}_ave.tr"
	OUT_NAME_AVE="TempAv_sta_${PRENAME}_SNR_${snrFlag[$snrInt]}.tr"
	for ((it=0; it<MAX_NO_OF_DROPS; it++))
	do					 
		FILE_NAME="${PRENAME}_STAs_File_SNR_${snrFlag[$snrInt]}_Rng_${it}.tr"
		echo "Processing $FILE_NAME"
		awk '{ 
			if(NR>20){
				for (i=1;i<=NF;i++) { 	
					printf "%2f ",$i
				}
				printf "\n"
			}
		}' $FILE_NAME > $OUT_NAME2

		#Average for each run
		awk '{ 	
			for (i=1;i<=NF;i++) {
				a[i]+=$i; 
			}
			} 
			END {
			if (NR > 0)
			{
				for (j=1;j<=NF;j++) {
					printf "%2f ",(a[j]/NR)
				}
				printf "\n"
			}
		}' $OUT_NAME2 >> $OUT_NAME_AVE

	done

	#Average
	awk '{ 	
	for (i=1;i<=NF;i++) {
		a[i]+=$i; 
	}
	} 
	END {
	for (j=1;j<=NF;j++) {
		printf "%2f ",(a[j]/NR)
	}
	printf "\n"
	}' $OUT_NAME_AVE >> $OUT_AVE
done	
				


