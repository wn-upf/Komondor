#!/bin/bash

function timer()
{
    if [[ $# -eq 0 ]]; then
        echo $(date '+%s')
    else
        local  stime=$1
        etime=$(date '+%s')

        if [[ -z "$stime" ]]; then stime=$etime; fi

        dt=$((etime - stime))
        ds=$((dt % 60))
        dm=$(((dt / 60) % 60))
        dh=$((dt / 3600))
        printf '%d:%02d:%02d' $dh $dm $ds
    fi
}



if [ "$#" -ne "3" ]
then 
	echo "No arguments supplied"
	exit 1
fi

if [ "$1" -gt "10" ]
then 
	echo "Wrong Drop start value"
	exit 1
fi

DROP_START=( 0 100 200 300 400 500 600 700 800 900 1000 )
DROP_NO_START=${DROP_START[$1]}
DROP_NO_STOP=${DROP_START[$1]}

START_OFFSET=$3

NUMBER_OF_RUNS=$2
DROP_NO_STOP=$((DROP_NO_STOP + NUMBER_OF_RUNS + START_OFFSET))
DROP_NO_START=$((DROP_NO_START + START_OFFSET))

if [ "$((NUMBER_OF_RUNS + START_OFFSET))" -gt "100" ]
then
	echo "Error too many runs $NUMBER_OF_RUNS"
	exit 1
fi

snrFlag=(0 1); #if true then snr is disabled
snrCnt=1;

APs=16;
STAs=16;

SimTime=100.0;

MCS=(9);
Traffic=(90000000 120000000);
mcsTrafCnt=1;

for ((snrInt=0; snrInt<snrCnt; snrInt++))
do 
	for ((mcsInt=0; mcsInt<mcsTrafCnt; mcsInt++))
	do 
		for ((it=DROP_NO_START; it<DROP_NO_STOP; it++))
		do 
			tmr=$(timer)
			echo "TGax Collaboration, SNR flag: ${snrFlag[$snrInt]}, Run: ${it}, STAs: ${STAs}, APs: ${APs}"
			./waf --run "scenario_complexity100 --RngRun=${it} --disableSnr=${snrFlag[$snrInt]} --StasNo=${STAs} --ApsNo=${APs} 
						 --generationRate=${Traffic[$mcsInt]} --rate=${MCS[$mcsInt]} --simulationTime=${SimTime}"
			echo " Finished: $(date) "
			printf '\nElapsed time: %s\n' $(timer $tmr)			
		done
	done
done
			
