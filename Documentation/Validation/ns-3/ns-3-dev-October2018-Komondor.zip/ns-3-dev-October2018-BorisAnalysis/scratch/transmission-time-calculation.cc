/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2017 5GIC, University of Surrey
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Ioannis Selinis <selinis.g@gmail.com>
 */


#include "ns3/core-module.h"
#include "ns3/wifi-module.h"
#include "ns3/wifi-phy.h"

using namespace ns3;

int main (int argc, char *argv[])
{

  Ptr<YansWifiPhy> phy = CreateObject<YansWifiPhy> ();
  WifiTxVector txvector;
  WifiMode mode;
	
  double timeSlot = 9;    // 9 @ 5GHz, 9 or 20 @ 2.4GHz
  double DIFS = 34;       // 34 @ 5GHz, 28 or 50 @ 2.4GHz
  double SIFS = 16;       // 16 @ 5GHz, 10 @ 2.4GHz
  double CWmin = 15;         // 7 or 15..
  double cwAverage = (CWmin - 1) / 2;
  double ACK = 44;        // BlockAck 44 @ 5GHz (ns3)

  double Preamble_leg = 20;  // This is duration of legacy preamble
  double Preamble_ht = 20;  // duration of 802.11n (see ns3)
  double Preamble_vht = 20;  // duration of 802.11ac (see ns3)
  double Preamble_he = 20;   // duration of 802.11ax (see ns3)
  double proDelay = 1;	   // Propagation delay
		
  std::vector<uint32_t> packetVector;
  packetVector.push_back (100);
  packetVector.push_back (1500);
	
  //////////////////////// IEEE 802.11a /////////////////////////////////
  std::cout<<"IEEE 802.11a (size, Time_date, MAC_effic, Mbps)"<<std::endl;
	
  SIFS = 16;
  timeSlot = 9;
  DIFS = SIFS + (2.0 * timeSlot);
  CWmin = 15;
  cwAverage = (CWmin - 1) / 2;
  ACK = 44;
  Preamble_leg = 20;
	
  txvector.SetNss (1);
  txvector.SetGuardInterval (800);
  txvector.SetChannelWidth (20);
  txvector.SetNess (0);
  txvector.SetStbc (1);
  txvector.SetPreambleType (WIFI_PREAMBLE_SHORT);
  mode = phy->GetOfdmRate54Mbps ();
  txvector.SetMode (mode);
	
  for (uint32_t ii = 0; ii < packetVector.size(); ii++)
  {
	  double transTime = (phy->CalculateTxDuration (packetVector.at(ii), txvector, 5500, NORMAL_MPDU, 0)).GetMicroSeconds() - Preamble_leg;
	  double macEfficiency = transTime / (DIFS + (timeSlot * cwAverage) + Preamble_leg + transTime + SIFS + ACK + (2.0 * proDelay));
	  double completeTrans = DIFS + (timeSlot * cwAverage) + Preamble_leg + transTime + SIFS + ACK + (2.0 * proDelay);
	  double totalTransAttempts = 1 / (completeTrans / 1e6); // convert to seconds
	  double mbps = ((8.0 * packetVector.at(ii)) * totalTransAttempts) / 1000000.0;
	  std::cout << packetVector.at(ii) << " " << (transTime / 1e3) << " " << macEfficiency << " " << mbps << " " << std::endl;
  }


  //////////////////////// IEEE 802.11b /////////////////////////////////
  std::cout<<"IEEE 802.11b (size, Time_date, MAC_effic, Mbps)"<<std::endl;
	
  SIFS = 10;
  timeSlot = 20;
  DIFS = SIFS + (2.0 * timeSlot);
  CWmin = 31;
  cwAverage = (CWmin - 1) / 2;
  ACK = 304;
  Preamble_leg = 72;
	
  txvector.SetNss (1);
  txvector.SetGuardInterval (800);
  txvector.SetChannelWidth (20);
  txvector.SetNess (0);
  txvector.SetStbc (1);
  txvector.SetPreambleType (WIFI_PREAMBLE_SHORT);
  mode = phy->GetDsssRate11Mbps ();
  txvector.SetMode (mode);
	
  for (uint32_t ii = 0; ii < packetVector.size(); ii++)
  {
	  double transTime = (phy->CalculateTxDuration (packetVector.at(ii), txvector, 2400, NORMAL_MPDU, 0)).GetMicroSeconds() - Preamble_leg;
	  double macEfficiency = transTime / (DIFS + (timeSlot * cwAverage) + Preamble_leg + transTime + SIFS + ACK + (2.0 * proDelay));
	  double completeTrans = DIFS + (timeSlot * cwAverage) + Preamble_leg + transTime + SIFS + ACK + (2.0 * proDelay);
	  double totalTransAttempts = 1 / (completeTrans / 1e6); // convert to seconds
	  double mbps = ((8.0 * packetVector.at(ii)) * totalTransAttempts) / 1000000.0;
	  std::cout << packetVector.at(ii) << " " << (transTime / 1e3) << " " << macEfficiency << " " << mbps << " " << std::endl;
  }
	
  //////////////////////// IEEE 802.11g /////////////////////////////////
  std::cout<<"IEEE 802.11g (size, Time_date, MAC_effic, Mbps)"<<std::endl;
	
  SIFS = 10;
  timeSlot = 20; // short timeslot = 9, if mixed deployment then timeSlot=20
  DIFS = SIFS + (2.0 * timeSlot);
  CWmin = 15;
  cwAverage = (CWmin - 1) / 2;
  ACK = 44; // Assume that you transmit ~6Mbps
  Preamble_leg = 20;
	
  txvector.SetNss (1);
  txvector.SetGuardInterval (800);
  txvector.SetChannelWidth (20);
  txvector.SetNess (0);
  txvector.SetStbc (1);
  txvector.SetPreambleType (WIFI_PREAMBLE_SHORT);
  mode = phy->GetErpOfdmRate54Mbps ();
  txvector.SetMode (mode);
	
  for (uint32_t ii = 0; ii < packetVector.size(); ii++)
  {
	  double transTime = (phy->CalculateTxDuration (packetVector.at(ii), txvector, 2400, NORMAL_MPDU, 0)).GetMicroSeconds() - Preamble_leg;
	  double macEfficiency = transTime / (DIFS + (timeSlot * cwAverage) + Preamble_leg + transTime + SIFS + ACK + (2.0 * proDelay));
	  double completeTrans = DIFS + (timeSlot * cwAverage) + Preamble_leg + transTime + SIFS + ACK + (2.0 * proDelay);
	  double totalTransAttempts = 1 / (completeTrans / 1e6); // convert to seconds
	  double mbps = ((8.0 * packetVector.at(ii)) * totalTransAttempts) / 1000000.0;
	  std::cout << packetVector.at(ii) << " " << (transTime / 1e3) << "  " << macEfficiency << " " << mbps << " " << std::endl;
  }
		
  packetVector.push_back (2800);
  packetVector.push_back (4000);
  packetVector.push_back (8000);
  packetVector.push_back (16000);
  packetVector.push_back (48000);
  packetVector.push_back (64000);

  //////////////////////// IEEE 802.11n_2.4 /////////////////////////////////
  std::cout<<"IEEE 802.11n 2.4 (size, Time_date, MAC_effic, Mbps)"<<std::endl;
	
  SIFS = 10;
  timeSlot = 20;
  DIFS = SIFS + (2.0 * timeSlot);
  CWmin = 15;
  cwAverage = (CWmin - 1) / 2;
  ACK = 44;
  Preamble_leg = 20;
	
  txvector.SetNss (1);
  txvector.SetGuardInterval (800);
  txvector.SetChannelWidth (20);
  txvector.SetNess (0);
  txvector.SetStbc (1);
  txvector.SetPreambleType (WIFI_PREAMBLE_HT_MF);
  mode = phy->GetHtMcs7 ();
  txvector.SetMode (mode);
	
  for (uint32_t ii = 0; ii < packetVector.size(); ii++)
  {
	  double transTime = (phy->CalculateTxDuration (packetVector.at(ii), txvector, 2400, NORMAL_MPDU, 0)).GetMicroSeconds() - Preamble_leg - Preamble_ht;
	  double macEfficiency = transTime / (DIFS + (timeSlot * cwAverage) + Preamble_leg + Preamble_ht + transTime + SIFS + ACK + (2.0 * proDelay));
	  double completeTrans = DIFS + (timeSlot * cwAverage) + Preamble_leg + Preamble_ht + transTime + SIFS + ACK + (2.0 * proDelay);
	  double totalTransAttempts = 1 / (completeTrans / 1e6); // convert to seconds
	  double mbps = ((8.0 * packetVector.at(ii)) * totalTransAttempts) / 1000000.0;
	  std::cout << packetVector.at(ii) << " " << (transTime / 1e3) << "  " << macEfficiency << " " << mbps << " " << std::endl;
  }

  //////////////////////// IEEE 802.11n_5 /////////////////////////////////
  std::cout<<"IEEE 802.11n 5 (size, Time_date, MAC_effic, Mbps)"<<std::endl;
	
  SIFS = 16;
  timeSlot = 9;
  DIFS = SIFS + (2.0 * timeSlot);
  CWmin = 15;
  cwAverage = (CWmin - 1) / 2;
  ACK = 44;
  Preamble_leg = 20;
	
  txvector.SetNss (1);
  txvector.SetGuardInterval (800);
  txvector.SetChannelWidth (20);
  txvector.SetNess (0);
  txvector.SetStbc (1);
  txvector.SetPreambleType (WIFI_PREAMBLE_HT_MF);
  mode = phy->GetHtMcs7 ();
  txvector.SetMode (mode);
	
  for (uint32_t ii = 0; ii < packetVector.size(); ii++)
  {
	  double transTime = (phy->CalculateTxDuration (packetVector.at(ii), txvector, 5500, NORMAL_MPDU, 0)).GetMicroSeconds() - Preamble_leg - Preamble_ht;
	  double macEfficiency = transTime / (DIFS + (timeSlot * cwAverage) + Preamble_leg + Preamble_ht + transTime + SIFS + ACK + (2.0 * proDelay));
	  double completeTrans = DIFS + (timeSlot * cwAverage) + Preamble_leg + Preamble_ht + transTime + SIFS + ACK + (2.0 * proDelay);
	  double totalTransAttempts = 1 / (completeTrans / 1e6); // convert to seconds
	  double mbps = ((8.0 * packetVector.at(ii)) * totalTransAttempts) / 1000000.0;
	  std::cout << packetVector.at(ii) << " " << (transTime / 1e3) << "  " << macEfficiency << " " << mbps << " " << std::endl;
  }

  packetVector.push_back (75000);
  packetVector.push_back (300000);
  packetVector.push_back (4000000);
	
  //////////////////////// IEEE 802.11ac /////////////////////////////////
  std::cout<<"IEEE 802.11ac (size, Time_date, MAC_effic, Mbps)"<<std::endl;
	
  SIFS = 16;
  timeSlot = 9;
  DIFS = SIFS + (2.0 * timeSlot);
  CWmin = 15;
  cwAverage = (CWmin - 1) / 2;
  ACK = 44;
  Preamble_leg = 20;
	
  txvector.SetNss (1);
  txvector.SetGuardInterval (800);
  txvector.SetChannelWidth (20);
  txvector.SetNess (0);
  txvector.SetStbc (1);
  txvector.SetPreambleType (WIFI_PREAMBLE_VHT);
  mode = phy->GetVhtMcs8 ();
  txvector.SetMode (mode);

  for (uint32_t ii = 0; ii < packetVector.size(); ii++)
  {
	  double transTime = (phy->CalculateTxDuration (packetVector.at(ii), txvector, 5500, NORMAL_MPDU, 0)).GetMicroSeconds() - Preamble_leg - Preamble_vht;
	  double macEfficiency = transTime / (DIFS + (timeSlot * cwAverage) + Preamble_leg + Preamble_vht + transTime + SIFS + ACK + (2.0 * proDelay));
	  double completeTrans = DIFS + (timeSlot * cwAverage) + Preamble_leg + Preamble_vht + transTime + SIFS + ACK + (2.0 * proDelay);
	  double totalTransAttempts = 1 / (completeTrans / 1e6); // convert to seconds
	  double mbps = ((8.0 * packetVector.at(ii)) * totalTransAttempts) / 1000000.0;
	  std::cout << packetVector.at(ii) << " " << (transTime / 1e3) << " " << macEfficiency << " " << mbps << " " << std::endl;
  }

  packetVector.push_back (6000000);

  //////////////////////// IEEE 802.11ax /////////////////////////////////
  std::cout<<"IEEE 802.11ax (size, Time_date, MAC_effic, Mbps)"<<std::endl;
	
  SIFS = 16;
  timeSlot = 9;
  DIFS = SIFS + (2.0 * timeSlot);
  CWmin = 15;
  cwAverage = (CWmin - 1) / 2;
  ACK = 44;
  Preamble_leg = 20;

  txvector.SetNss (1);
  txvector.SetGuardInterval (3200);
  txvector.SetChannelWidth (20);
  txvector.SetNess (0);
  txvector.SetStbc (1);
  txvector.SetPreambleType (WIFI_PREAMBLE_HE_SU);
  mode = phy->GetHeMcs11 ();
  txvector.SetMode (mode);

  for (uint32_t ii = 0; ii < packetVector.size(); ii++)
  {
	  double transTime = (phy->CalculateTxDuration (packetVector.at(ii), txvector, 5500, NORMAL_MPDU, 0)).GetMicroSeconds() - Preamble_leg - Preamble_he;	  
	  double macEfficiency = transTime / (DIFS + (timeSlot * cwAverage) + Preamble_leg + Preamble_he + transTime + SIFS + ACK + (2.0 * proDelay) /*+ (72.8+SIFS+44+SIFS)*/);
	  double completeTrans = DIFS + (timeSlot * cwAverage) + Preamble_leg + Preamble_he + transTime + SIFS + ACK + (2.0 * proDelay) /*+ (72.8+SIFS+44+SIFS)*/;
	  double completeTransRts = completeTrans + 2 * SIFS + 76 + 44; //RTS=76 microSec, CTS=44 microSec
	  double totalTransAttempts = 1 / (completeTrans / 1e6); // convert to seconds
	  double totalTransAttemptsRts = 1 / (completeTransRts / 1e6); // convert to seconds
	  double mbps = ((8.0 * packetVector.at(ii)) * totalTransAttempts) / 1000000.0;
	  double mbpsRts = ((8.0 * packetVector.at(ii)) * totalTransAttemptsRts) / 1000000.0;
	  std::cout << packetVector.at(ii) << " " << (transTime / 1e3) << " " << macEfficiency << " " << mbps << " " << mbpsRts << std::endl;
  }
  return 0;
}

